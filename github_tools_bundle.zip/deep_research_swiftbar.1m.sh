#!/bin/bash
# <xbar.title>Deep Research Trigger</xbar.title>
# <xbar.version>v1.0</xbar.version>
# <xbar.author>Your Name</xbar.author>
# <xbar.desc>Triggers GPT Deep Research Assistant</xbar.desc>
# <xbar.refreshOnClick>true</xbar.refreshOnClick>

echo "🧠 Deep Research"
echo "---"
echo "Run Now | bash='/usr/bin/python3' param1='/Users/macmini/Deep_Research_Workflow/deep_research_runner.py' terminal=false"
